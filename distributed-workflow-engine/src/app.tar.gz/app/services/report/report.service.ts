import { Injectable } from '@angular/core';

@Injectable()
export class ReportService {

  constructor() { }

}
