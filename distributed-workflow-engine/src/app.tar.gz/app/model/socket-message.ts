export class SocketMessage{
    message: String;

    constructor(message){
        this.message = message;
    }
}