export class Task{


taskType: String ; 	
status : String; 	
depends_on: String[]; 	
output: String[]; 	
input:String[] ;

	
}