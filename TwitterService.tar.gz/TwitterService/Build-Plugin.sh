#!/bin/bash
#cd /home/avalabche/testrun2/Spring_restapi
cd "$1"
mvn clean package
