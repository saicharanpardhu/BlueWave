export var multi = [
  {
    name: "workflow1",
    description: "ss",
    series: [
      {
        name: "2010",
        value: 10
      },
      {
        name: "2011",
        value: 5
      }
    ]
  },
  {
    name: "workflow2",
    series: [
      {
        name: "2010",
        value: 1
      },
      {
        name: "2011",
        value: 13
      }
    ]
  },
  {
    name: "workflow5",
    series: [
      {
        name: "2010",
        value: 1
      },
      {
        name: "2011",
        value: 13
      }
    ]
  },
  {
    name: "workflow4",
    series: [
      {
        name: "2010",
        value: 1
      },
      {
        name: "2015",
        value: 13
      },
      {
        name: "2012",
        value: 13
      }
    ]
  },
  {
    name: "workflow33",
    series: [
      {
        name: "2010",
        value: 1
      },
      {
        name: "2011",
        value: 13
      }
    ]
  },
  {
    name: "workflow21233",
    series: [
      {
        name: "2010",
        value: 1
      },
      {
        name: "2011",
        value: 13
      }
    ]
  },
  {
    name: "workflow11233",
    series: [
      {
        name: "2010",
        value: 1
      },
      {
        name: "2011",
        value: 13
      }
    ]
  },
  {
    name: "workflow23221",
    series: [
      {
        name: "2010",
        value: 1
      },
      {
        name: "2011",
        value: 13
      }
    ]
  },
  {
    name: "workflow54",
    series: [
      {
        name: "2010",
        value: 1
      },
      {
        name: "2011",
        value: 13
      }
    ]
  },
  {
    name: "workflow14",
    series: [
      {
        name: "2010",
        value: 1
      },
      {
        name: "2015",
        value: 13
      },
      {
        name: "2012",
        value: 13
      }
    ]
  },
  {
    name: "workflow323",
    series: [
      {
        name: "2010",
        value: 1
      },
      {
        name: "2011",
        value: 13
      }
    ]
  },
  {
    name: "workflow233",
    series: [
      {
        name: "2010",
        value: 1
      },
      {
        name: "2011",
        value: 13
      }
    ]
  },
  {
    name: "workflow213",
    series: [
      {
        name: "2010",
        value: 1
      },
      {
        name: "2011",
        value: 13
      }
    ]
  }
];
