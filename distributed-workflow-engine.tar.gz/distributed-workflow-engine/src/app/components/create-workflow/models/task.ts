export class Task {
  type?: String;
  status?: String;
  depends_on?: String[];
  output?: String[];
  input?: String[];
}
