export class Task {
  taskAlias?: any;
  taskStartTime?: any;
  taskEndTime?: any;
  taskLogs?: any;
}
